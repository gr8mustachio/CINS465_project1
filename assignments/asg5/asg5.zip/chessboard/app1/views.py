from django.http import HttpResponse
from django.shortcuts import render
from app1.models import Board
import html
from app1.forms import ChessForm

valid_cols = ["a", "b", "c", "d", "e", "f", "g", "h"]
valid_rows = [1, 2, 3, 4, 5, 6, 7, 8]
def home(request):
    page_data = { "rows": [], "chess_form": ChessForm }
    if (Board.objects.all().count() == 0) or (request.method == 'POST' and 'new_game' in request.POST):
        newGame(request)
    elif (request.method == 'POST'):
        chess_form = ChessForm(request.POST)
        if (chess_form.is_valid()):
            location = chess_form.cleaned_data["location"]
            new_location = chess_form.cleaned_data["new_location"]
            piece = Board.objects.get(name=location).value
            Board(name=new_location, value=piece).save()
            Board(name=location, value = html.unescape('&nbsp;')).save()
            #trying to access piece to be moved in these instructions
            #COMMENTED OUT LINES ARE DEBUGGING STUFF / STEPS IN WHAT I'M TRYING TO DO THAT ARE CAUSING ERRORS
            #rowList = page_data.get("rows") #accessing value of key "row" which is a list object

            #newRow = int(new_location[1]) # this is the '2' in the position 'a2'
            #rowInd = (len(rowList) - newRow)+8 # math equation I figured out to calculate the index of the specific row
            #pieceRow = rowList[rowInd] #gives error due to list being empty. first step of errors
            #piece = pieceRow.get(location) #next step
            #value = rowInd # <--- this line shows the index of the row of the table in the list of dictionaries
            #value = len(rowList) #rowList is somehow empty
            #value = piece #(WHAT I'VE BEEN TRYING TO DO)

            #dest = Board.objects.get(name=new_location)
            #value = piece
            #IGNORE NEXT LINE (irrevlant to debugging but I want the original in case I break something)
            #value = chess_form.cleaned_data["new_location"]
            #Board(name=name, value=value).save() #saves location to backend
        else:
            page_data["chess_form"] = chess_form

        #populate page_data from board model
        #doesn't work with reversed
    for row in reversed(valid_rows):
        row_data = {}
        for col in valid_cols:
            id = "{}{}".format(col,row)
            try:
                record = Board.objects.get(name=id)
                row_data[id] = record.value
            except Board.DoesNotExist:
                row_data[id] = html.unescape('&nbsp;')
        page_data.get("rows").append(row_data)

    return render(request, 'app1/home.html', page_data)




def newGame(request):
    page_data = {
    "rows": [
    {"a8": html.unescape('&#9814;'), "b8": html.unescape('&#9816;'), "c8": html.unescape('&#9815;'), "d8": html.unescape('&#9813;'), "e8": html.unescape('&#9812;'), "f8": html.unescape('&#9815;'), "g8": html.unescape('&#9816;'), "h8": html.unescape('&#9814;')},
    {"a7": html.unescape('&#9817;'), "b7": html.unescape('&#9817;'), "c7": html.unescape('&#9817;'), "d7": html.unescape('&#9817;'), "e7": html.unescape('&#9817;'), "f7": html.unescape('&#9817;'), "g7": html.unescape('&#9817;'), "h7": html.unescape('&#9817;')},
    {"a6": html.unescape('&nbsp;'), "b6": html.unescape('&nbsp;'), "c6": html.unescape('&nbsp;'), "d6": html.unescape('&nbsp;'), "e6": html.unescape('&nbsp;'), "f6": html.unescape('&nbsp;'), "g6": html.unescape('&nbsp;'), "h6": html.unescape('&nbsp;')},
    {"a5": html.unescape('&nbsp;'), "b5": html.unescape('&nbsp;'), "c5": html.unescape('&nbsp;'), "d5": html.unescape('&nbsp;'), "e5": html.unescape('&nbsp;'), "f5": html.unescape('&nbsp;'), "g5": html.unescape('&nbsp;'), "h5": html.unescape('&nbsp;')},
    {"a4": html.unescape('&nbsp;'), "b4": html.unescape('&nbsp;'), "c4": html.unescape('&nbsp;'), "d4": html.unescape('&nbsp;'), "e4": html.unescape('&nbsp;'), "f4": html.unescape('&nbsp;'), "g4": html.unescape('&nbsp;'), "h4": html.unescape('&nbsp;')},
    {"a3": html.unescape('&nbsp;'), "b3": html.unescape('&nbsp;'), "c3": html.unescape('&nbsp;'), "d3": html.unescape('&nbsp;'), "e3": html.unescape('&nbsp;'), "f3": html.unescape('&nbsp;'), "g3": html.unescape('&nbsp;'), "h3": html.unescape('&nbsp;')},
    {"a2": html.unescape('&#9823;'), "b2": html.unescape('&#9823;'), "c2": html.unescape('&#9823;'), "d2": html.unescape('&#9823;'), "e2": html.unescape('&#9823;'), "f2": html.unescape('&#9823;'), "g2": html.unescape('&#9823;'), "h2": html.unescape('&#9823;')},
    {"a1": html.unescape('&#9820;'), "b1": html.unescape('&#9822;'), "c1": html.unescape('&#9821;'), "d1": html.unescape('&#9819;'), "e1": html.unescape('&#9818;'), "f1": html.unescape('&#9821;'), "g1": html.unescape('&#9822;'), "h1": html.unescape('&#9820;')},
    ]
    }

   #deleting all board model objects
    Board.objects.all().delete()
    #return render(request, 'app1/home.html', page_data);

    #populating all board model objects from page_data
    for row in page_data.get("rows"):
        for name, value in row.items():
            Board(name=name, value=value).save()


def history(request):
    return render(request, 'app1/history.html');

def about(request):
    return render(request, 'app1/about.html');

def rules(request):
    return render(request, 'app1/rules.html');
